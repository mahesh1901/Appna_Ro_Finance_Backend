package Com.finance.CustomeException;

public enum CustomerEnu {
	
	
	Applied , 
	

	Verified , 
	
	Rejected , 
	
		

	Customer_Rejected,  Customer_Accepted, 


	Sanction_Genetrated , 
	
	Loan_Disbursed, 
	
	Ledger_Generated
	
}

