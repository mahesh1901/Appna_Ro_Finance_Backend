package Com.finance.CustomeException;

public enum EnquiryStatus {

	Enquired, Cibilok, Cibilreject,

}
