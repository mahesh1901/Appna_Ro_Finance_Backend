package Com.finance.CustomeException;


public enum LedgerLoanStatusEnum {
	Standard,
	Non_Performing_Asset,
	Bad_Loan,
	Loan_Cleared
	
}
