package Com.finance.CustomeException;

public enum InstallmentEnum {
	NA,
	Paid,
	UnPaid
}
