package Com.finance.CustomeException;

public enum ErrorInfo {

	Customer_Is_Not_Available,Customer_Already_Exists, Dublicate_Mobile_No,
	Dublicate_PanCard_No, 
}
