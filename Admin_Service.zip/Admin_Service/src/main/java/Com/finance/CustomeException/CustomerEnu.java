package Com.finance.CustomeException;

public enum CustomerEnu {
	
	
	Applied , 
	

	Verified , 
	
	Rejected , 
	
	Sanction_Generate,
		

	Customer_Rejected,  Customer_Accepted, 


	Sanction_Genetrated , 
	
	Loan_Disbursed, 
	
	Ledger_Generated
	
}

