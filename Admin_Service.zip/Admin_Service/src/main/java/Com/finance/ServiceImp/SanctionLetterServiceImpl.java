
package Com.finance.ServiceImp;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import Com.finance.CustomeException.BaseResponce;
import Com.finance.CustomeException.CustomerEnu;
import Com.finance.Model.Customer;
import Com.finance.Model.SanctionLetter;
import Com.finance.Repositary.SanctionLetterRepository;
import Com.finance.Servicei.ApiClient;
import Com.finance.Servicei.SanctionLetterService;

@Service
public class SanctionLetterServiceImpl implements SanctionLetterService {

	private static final String CUSTOMER_MICROSERVICE_URL = "http://mahesh:8083/customer/getcustomerbyid/{customerId}";

//	@Autowired
//	private RestTemplate restTemplate;

	@Autowired
	private ApiClient apiclient;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private SanctionLetterRepository slr;

	private Logger logger = LoggerFactory.getLogger(SanctionLetterServiceImpl.class);

	@Override
	public SanctionLetter generatesanction(SanctionLetter sanctionLetter, String customerId) {
		try {

			System.out.println("Enter  in Section letter");
			System.out.println(customerId  + "   Customer Id ");

			BaseResponce<Customer> BaseRescustomer = apiclient.getOneCustomer(customerId);
			 Customer customer = BaseRescustomer.getResponceData();
			 System.out.println("Customer  Data :"+  customer.getCustomerVerificationStatus());
							
			
			System.out.println(customer.getCustomerFirstName()+"  : customer First Name");

			System.out.println("***************************************************************************");
			
			int nextInt = ThreadLocalRandom.current().nextInt(999, 9999);
			Long randomeNumber = Long.valueOf(nextInt);

			sanctionLetter.setSanctionId(randomeNumber);

			sanctionLetter.setSanctionDate(new Date());
			System.out.println(customer.getCustomerFirstName());
			sanctionLetter.setApplicantName(customer.getCustomerFirstName());
			sanctionLetter.setSanctionLetterStatus("Sanction_Generated");

			SanctionLetter san = slr.save(sanctionLetter);

////            Customer customer = responseEntity.getBody();
//			customer.setSanctionLetter(san);
//			customer.setCustomerVerificationStatus(String.valueOf(CustomerEnu.Sanction_Generate));
//			slr.save(customer);

			logger.info("Sanction Letter pdf started");

			// Send email with attached PDF
			sendSanctionLetterEmail(customer.getCustomerEmail(), san);

			return san;
		} catch (HttpClientErrorException ex) {
			// Handle HTTP client errors (e.g., 404, 500)
			HttpStatus statusCode = (HttpStatus) ex.getStatusCode();
			String responseBody = ex.getResponseBodyAsString();
			logger.error("HTTP Error: Status Code - {}, Response Body - {}", statusCode, responseBody);
			throw new RuntimeException("Failed to fetch customer details: " + ex.getMessage(), ex);
		} catch (Exception e) {
			// Handle other exceptions
			logger.error("Error occurred while generating sanction letter: {}", e.getMessage(), e);
			throw new RuntimeException("Failed to generate sanction letter: " + e.getMessage(), e);
		}
	}

	private void sendSanctionLetterEmail(String recipientEmail, SanctionLetter sanctionLetter) {
		// Implementation to send email with PDF attachment
	}

	@Override
	public List<SanctionLetter> getSanctiondata()
	{
		 return  slr.findAll();
		
	}
}

