package com.finance.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppnaRoFinanceServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
