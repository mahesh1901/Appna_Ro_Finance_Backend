package com.finance.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppnaRoFinanceCommon1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
